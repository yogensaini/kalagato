//
//  PostEntity+CoreDataClass.swift
//  KalaGato
//
//  Created by Yogender Saini on 02/09/23.
//
//

import Foundation
import CoreData

@objc(PostEntity)
public class PostEntity: NSManagedObject {

}
