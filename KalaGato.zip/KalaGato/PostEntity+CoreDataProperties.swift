//
//  PostEntity+CoreDataProperties.swift
//  KalaGato
//
//  Created by Yogender Saini on 02/09/23.
//
//

import Foundation
import CoreData


extension PostEntity {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<PostEntity> {
        return NSFetchRequest<PostEntity>(entityName: "PostEntity")
    }

    @NSManaged public var body: String?
    @NSManaged public var id: String?
    @NSManaged public var title: String?
    @NSManaged public var userId: String?
    @NSManaged public var isFavourite: Bool

}

extension PostEntity : Identifiable {

}
