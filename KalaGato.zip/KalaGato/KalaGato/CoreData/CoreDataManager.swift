//
//  CoreDataManager.swift
//  KalaGato
//
//  Created by Yogender Saini on 31/08/23.
//

import Foundation
import UIKit
import CoreData

class CoreDataManager {
    
    private var context: NSManagedObjectContext {
        return (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    }
    
    func addAllPost(_ posts: [Post]) {
        
        self.deleteEntityData(entity: "PostEntity")
        
        for index in 0...posts.count-1 {
            let postEntity = PostEntity(context: context)
            addUpdatePost(postEntity: postEntity, postModel: posts[index])
        }
        
    }
    
    func addPost(_ post: Post) {
        let postEntity = PostEntity(context: context)
        addUpdatePost(postEntity: postEntity, postModel: post)
    }
    
    func updatePost(post: Post, postEntity: PostEntity) {
        addUpdatePost(postEntity: postEntity, postModel: post)
    }
    
    func updatePost(post: Post) {
        let postEntity = PostEntity(context: context)
        addUpdatePost(postEntity: postEntity, postModel: post)
    }
    
    
    private func addUpdatePost(postEntity: PostEntity, postModel: Post) {
        postEntity.id =  String(postModel.id)
        postEntity.userId = String(postModel.userId)
        postEntity.title = postModel.title
        postEntity.body = postModel.body
        saveContext()
    }
    
    
    func fetchUsers() -> [Post] {
        var arrNewPost: [PostEntity] = []
        var arrPost: [Post] = []
        
        do {
            arrNewPost = try context.fetch(PostEntity.fetchRequest())
            if arrNewPost.count == 0 {
                return arrPost
            }
            for index in 0...arrNewPost.count-1 {
                let post = Post(id: Int(arrNewPost[index].id!) ?? 0, userId: Int(arrNewPost[index].userId!) ?? 0 , title: arrNewPost[index].title!, body: arrNewPost[index].body!, isFavourite: arrNewPost[index].isFavourite)
                arrPost.append(post)
            }
        }catch {
            print("Fetch user error", error)
        }
        return arrPost
    }
    
    func saveContext() {
        do {
            try context.save()
        }catch {
            print("User saving error:", error)
        }
    }
    
    func deleteUser(postEntity: PostEntity) {
        context.delete(postEntity)
        saveContext()
    }
    
    func deleteEntityData(entity : String) {
        
        let context = ( UIApplication.shared.delegate as! AppDelegate ).persistentContainer.viewContext
        let deleteFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "PostEntity")
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: deleteFetch)
        do
        {
            try context.execute(deleteRequest)
            try context.save()
        }
        catch
        {
            print ("There was an error no data in stack")
        }
    }
        
    func updateIsFavouriteValue(isFav: Bool, postId : String){
                
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "PostEntity")
        fetchRequest.predicate = NSPredicate(format: "id == %@", postId)
        do {
            let result = try context.fetch(fetchRequest)  as? [NSManagedObject]
            if result?.count != 0 {
                result![0].setValue(isFav, forKey: "isFavourite")
                self.saveContext()
            }
        } catch {
            print("failed to fetch record from CoreData")
        }
    }
}
