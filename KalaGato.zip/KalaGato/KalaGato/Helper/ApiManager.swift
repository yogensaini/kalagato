//
//  ApiManager.swift
//  KalaGato
//
//  Created by Yogender Saini on 30/08/23.
//

import Foundation

class ApiManager {
    
    static let shared = ApiManager()
        
    typealias handler<T> = (Result<T, customErrorType>)->Void
    
    func commonRequest<T : Decodable>(
        modelType : T.Type,
        endPointType : EndPointType,
        complition : @escaping handler<T>){
        
            guard let url = endPointType.url else {
                complition(.failure(.InvalidUrl))
                return
            }
                        
           // debugPrint(url)
            
            URLSession.shared.dataTask(with: url) { data, response, error in
                guard let data, error == nil else {
                    complition(.failure(.InvalidData))
                    return
                }
                
                guard let response = response as? HTTPURLResponse, 200...299 ~= response.statusCode else {
                    complition(.failure(.InvalidResponse))
                    return
                }
                
                do {
                    let result = try JSONDecoder().decode(modelType, from: data)
                    complition(.success(result))
                } catch(let err){
                    debugPrint(err)
                    complition(.failure(.error(err)))
                }
            }.resume()
    }

}

enum customErrorType : Error {
    case InvalidUrl
    case InvalidResponse
    case InvalidData
    case error(Error?)
}
