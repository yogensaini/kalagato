//
//  Extensions.swift
//  KalaGato
//
//  Created by Yogender Saini on 31/08/23.
//

import UIKit

extension UIViewController {
    
    func showAlert(title : String, msg : String) {
        let refreshAlert = UIAlertController(title: title, message: msg, preferredStyle: UIAlertController.Style.alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
            debugPrint("OK")
        }))
        
//        refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
//        }))
        present(refreshAlert, animated: true, completion: nil)
    }
}
