//
//  Path.swift
//  KalaGato
//
//  Created by Yogender Saini on 30/08/23.
//


import Foundation

enum HttpMethod : String {
    case get = "GET"
    case post = "POST"
}

enum EndPointItems {
    case Posts
    case Comments
    case GetComments(post_id : Int)
}

protocol EndPointType {
    var path : String {get}
    var baseUrl : String {get}
    var url : URL? {get}
    var method : HttpMethod {get}
}

extension EndPointItems : EndPointType {
    var path: String {
        switch self {
        case .Posts :
            return "/posts"
        case .Comments :
            return "/posts/2/comments"
        case .GetComments(let post_id) :
            return "/posts/\(post_id)/comments"
        }
        
    }
    
    var baseUrl: String {
        return "https://jsonplaceholder.typicode.com"
    }
    
    var url: URL? {
        return URL(string: "\(baseUrl)\(path)")
    }
    
    var method: HttpMethod {
        switch self {
        case .Posts :
            return .get
        case .Comments :
            return .get
        case .GetComments(post_id: let post_id):
            return .post
        }
        
    }
    
    
}


