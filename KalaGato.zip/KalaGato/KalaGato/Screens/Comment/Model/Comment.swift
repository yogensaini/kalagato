//
//  Comment.swift
//  KalaGato
//
//  Created by Yogender Saini on 30/08/23.
//

import Foundation

struct Comment : Codable {
    var id : Int
    var postId : Int
    var name : String
    var body : String
    var email : String
}
