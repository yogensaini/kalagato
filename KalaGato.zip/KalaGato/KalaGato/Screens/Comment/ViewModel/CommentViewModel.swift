//
//  CommentViewModel.swift
//  KalaGato
//
//  Created by Yogender Saini on 30/08/23.
//

import Foundation

class CommentViewModel {
            
    var comment : [Comment] = []
    var eventHandler : ((_ event : Events) -> Void)?
    
    func getCommentsList(post_id : Int){
        
        self.eventHandler?(.loading)
        ApiManager.shared.commonRequest(modelType: [Comment].self, endPointType: EndPointItems.GetComments(post_id: post_id)) { responce in
            self.eventHandler?(.stopLoading)
            switch responce {
            case .failure(let err):
                debugPrint(err)
                self.eventHandler?(.error(err))
            case .success(let pd):
                self.comment = pd
                self.eventHandler?(.dataLoading)
            }
        }
    }
    
}
extension CommentViewModel {
    
    enum Events {
        case loading
        case stopLoading
        case dataLoading
        case error(Error?)
    }
}
