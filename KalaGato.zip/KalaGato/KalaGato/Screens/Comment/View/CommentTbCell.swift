//
//  CommentTbCell.swift
//  KalaGato
//
//  Created by Yogender Saini on 31/08/23.
//

import UIKit

class CommentTbCell: UITableViewCell {

    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var EmailLabel: UILabel!
    @IBOutlet weak var NameLabel: UILabel!
    @IBOutlet weak var BodyLabel: UILabel!
    
    var comment: Comment? {
        didSet {
            commentSetup()
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        bgView.clipsToBounds = false
        bgView.layer.cornerRadius = 5
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
 
    func commentSetup() {
        guard let comment else { return }
        EmailLabel.text =  comment.email
        NameLabel.text = comment.name
        BodyLabel.text = comment.body
        
        print(comment.name)
        print(comment.body)
        print(comment.email)
    }
    
}
