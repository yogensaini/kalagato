//
//  CommentVC.swift
//  KalaGato
//
//  Created by Yogender Saini on 30/08/23.
//

import UIKit

class CommentVC: UIViewController {

    @IBOutlet weak var tblView : UITableView!
    private var viewModel = CommentViewModel()
    private let manager =  CoreDataManager()

    var post : Post?
    var btnTitle = "Favorite"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.dataConfiguration()
        btnTitle = (post?.isFavourite == false) ? "Favorite" : "UnFavorite"
        let btn = UIBarButtonItem(title: btnTitle, style: .plain, target: self, action: #selector(self.setFavourit))
        navigationItem.rightBarButtonItem = btn
    }

    @objc func setFavourit(){
        debugPrint("Make it favourit")
        if self.btnTitle == "Favorite" {
            self.navigationItem.rightBarButtonItem?.title = "UnFavorite"
            self.btnTitle = "UnFavorite"
            self.updateInRecrod(isFav: true)
        } else {
            self.navigationItem.rightBarButtonItem?.title = "Favorite"
            self.btnTitle = "Favorite"
            self.updateInRecrod(isFav: false)
        }
    }
    
    func updateInRecrod(isFav : Bool){
        debugPrint("First Record ---------------------------->", post!.id, isFav)
        manager.updateIsFavouriteValue(isFav: isFav, postId: String(self.post!.id))
    }
    
    static func getInstance() -> CommentVC {
        let stBoard = UIStoryboard(name: "Main", bundle: nil)
        return stBoard.instantiateViewController(withIdentifier: "CommentVC") as! CommentVC
    }
    
}

extension CommentVC: UITableViewDataSource {

func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    debugPrint(self.viewModel.comment.count)

    return self.viewModel.comment.count +  1
}

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "PostTbCell") as? PostTbCell else {
                return UITableViewCell()
            }
            cell.post = post
            return cell
        } else {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "CommentTbCell") as? CommentTbCell else {
                return UITableViewCell()
            }
            let cmt = self.viewModel.comment[indexPath.row-1]
            cell.comment = cmt
            return cell
        }
    }
}
extension CommentVC {

func dataConfiguration(){
    tblView.register(UINib(nibName: "PostTbCell", bundle: nil), forCellReuseIdentifier: "PostTbCell")
    tblView.register(UINib(nibName: "CommentTbCell", bundle: nil), forCellReuseIdentifier: "CommentTbCell")
    
    if Reachability().isConnectedToNetwork() == true {
        self.viewModel.getCommentsList(post_id: self.post?.id ?? 0)
        self.UpdateEvents()
    } else {
        self.showAlert(title: "oops!", msg: "You are offline")
    }    
}

func UpdateEvents(){
    
    self.viewModel.eventHandler = { [weak self] event in
        guard let self else {
            return
        }
        switch event {
        case .loading :
            debugPrint("loading")
        case .stopLoading :
            debugPrint("stop loading")
        case .dataLoading :
            debugPrint("Data is loading")
            debugPrint(self.viewModel.comment.count)
            DispatchQueue.main.async {
                self.tblView.reloadData()
            }
        case .error(let err) :
            debugPrint("Error occured", err)
        }
    }
}
}
