//
//  FavouritVC.swift
//  KalaGato
//
//  Created by Yogender Saini on 31/08/23.
//

import UIKit

class FavouritVC: UIViewController {

    private let manager =  CoreDataManager()
    @IBOutlet weak var tblView : UITableView!
    var arrFav = [Post]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblView.register(UINib(nibName: "PostTbCell", bundle: nil), forCellReuseIdentifier: "PostTbCell")
        getFavouriteData()
    }
    
    func getFavouriteData(){
        let arr = manager.fetchUsers()
        self.arrFav = arr.filter({ post in
            return post.isFavourite == true
        })
        self.tblView.reloadData()
    }
}
extension FavouritVC: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.arrFav.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "PostTbCell") as? PostTbCell else {
            return UITableViewCell()
        }
        let post = self.arrFav[indexPath.row]
        cell.post = post
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
}
