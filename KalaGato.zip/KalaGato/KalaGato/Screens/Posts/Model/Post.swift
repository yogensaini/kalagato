//
//  Post.swift
//  KalaGato
//
//  Created by Yogender Saini on 30/08/23.
//

import Foundation

struct Post : Codable {
    var id : Int
    var userId : Int
    var title : String
    var body : String
    var isFavourite : Bool?
}
