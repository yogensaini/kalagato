//
//  PostViewModel.swift
//  KalaGato
//
//  Created by Yogender Saini on 30/08/23.
//

import Foundation

class PostViewModel {
    
    var posts : [Post] = []
    var eventHandler : ((_ event : Events) -> Void)?
    
    func getPostList(){
        
        self.eventHandler?(.loading)
        ApiManager.shared.commonRequest(modelType: [Post].self, endPointType: EndPointItems.Posts) { responce in
            self.eventHandler?(.stopLoading)
            switch responce {
            case .failure(let err):
                debugPrint(err)
                self.eventHandler?(.error(err))
            case .success(let pd):
                self.posts = pd
                self.eventHandler?(.dataLoading)
            }
        }
    }
    
}

extension PostViewModel {
    
    enum Events {
        case loading
        case stopLoading
        case dataLoading
        case error(Error?)
    }
}
