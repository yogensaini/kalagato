//
//  PostTbCell.swift
//  KalaGato
//
//  Created by Yogender Saini on 31/08/23.
//

import UIKit

class PostTbCell: UITableViewCell {

    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var TitleLabel: UILabel!
    @IBOutlet weak var DescLabel: UILabel!
    
    var post: Post? {
        didSet {
            postSetup()
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        bgView.clipsToBounds = false
        bgView.layer.cornerRadius = 5
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
 
    func postSetup() {
        guard let post else { return }
        TitleLabel.text = post.title
        DescLabel.text = post.body
        debugPrint(post.id)
        debugPrint(post.userId)
    }
}
