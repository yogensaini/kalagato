//
//  PostVC.swift
//  KalaGato
//
//  Created by Yogender Saini on 30/08/23.
//

import UIKit

class PostVC: UIViewController {

    @IBOutlet weak var tblView : UITableView!
    private var viewModel = PostViewModel()
    private let manager =  CoreDataManager()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Remote config.
        /*
         for remote config we need to conifg app in firebase, after downloading googleinfo.plist, we can set diff type of remote config.
         for upate data in offline add to synk on server we need a input post api, that store aryy of past to server.
//        self.view.backgroundColor = UIColor.gray
         */
        
        self.dataConfiguration()
    }
}
extension PostVC: UITableViewDataSource, UITableViewDelegate {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.posts.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "PostTbCell") as? PostTbCell else {
            return UITableViewCell()
        }
        let post = viewModel.posts[indexPath.row]
        cell.post = post
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if Reachability().isConnectedToNetwork() == true {
            let vc = CommentVC.getInstance()
            vc.post = self.viewModel.posts[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
        } else {
            self.showAlert(title: "oops!", msg: "You are offline")
        }
    }

}
extension PostVC {
    
    func dataConfiguration(){
        tblView.register(UINib(nibName: "PostTbCell", bundle: nil), forCellReuseIdentifier: "PostTbCell")
        
        if Reachability().isConnectedToNetwork() == true {
            self.viewModel.getPostList()
            self.UpdateEvents()
        } else {
            self.getPostOffLineData()
            self.showAlert(title: "oops!", msg: "You are offline")
        }
    }

    func saveDataCoreData() {
        manager.addAllPost(self.viewModel.posts)
        self.getPostOffLineData()
    }
    
    func getPostOffLineData(){
        let arr = manager.fetchUsers()
        self.viewModel.posts = arr
        self.tblView.reloadData()
    }
    
    func UpdateEvents(){
        self.viewModel.eventHandler = { [weak self] event in
            guard let self else {
                return
            }
            switch event {
            case .loading :
                debugPrint("loading")
            case .stopLoading :
                debugPrint(" stop loading")
            case .dataLoading :
                debugPrint("Data is loading")
                debugPrint(self.viewModel.posts.count)
                DispatchQueue.main.async {
//                    self.tblView.reloadData()
                    self.saveDataCoreData()
                }
            case .error(let err) :
                debugPrint("Error occured", err)
            }
        }
    }
}

